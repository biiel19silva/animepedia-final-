<footer class="rodapé">
  <p>© 2025 Animepedia. Todos os direitos reservados.</p>
  <p>Este projeto é uma ferramenta educacional e não comercial. As informações e imagens de animes são utilizadas para fins de demonstração, aprendizado e ilustração de conceitos de desenvolvimento web.</p>
</footer>
