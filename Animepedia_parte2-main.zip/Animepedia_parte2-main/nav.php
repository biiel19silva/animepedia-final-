    <nav>
        <a href="index.php">Home</a> |
        <a href="catalogo.php">Catálogo</a> |
        <a href="sac.php">SAC</a> |
        <a href="equipe.php">Equipe</a> | 
        <a id="alternaTema" href="#"></a> 
    </nav>
