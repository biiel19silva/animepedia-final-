<header class="cabeçalho">
  <h1>Animepedia: a sua enciclopedia digital de personagens de animes</h1>
</header>
